﻿using System;

namespace ContentConsole
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            string bannedWord1 = "swine";
            string bannedWord2 = "bad";
            string bannedWord3 = "nasty";
            string bannedWord4 = "horrible";

            string contentOriginal = "The weather in Manchester in winter is bad. It rains all the time - it must be horrible for people visiting.";
            string content = contentOriginal;
            int badWords = 0;

            if (content.Contains(bannedWord1))
            {
                badWords = badWords + 1;
            }
            if (content.Contains(bannedWord2))
            {
                badWords = badWords + 1;
            }
            if (content.Contains(bannedWord3))
            {
                badWords = badWords + 1;
            }
            if (content.Contains(bannedWord4))
            {
                badWords = badWords + 1;
            }

            Console.WriteLine("Scanned the text:");
            Console.WriteLine(content);
            Console.WriteLine("Total Number of negative words: " + badWords);

            //Console.WriteLine("Press ANY key to exit.");
            //Console.ReadKey();
            Console.WriteLine("Do you want to Override these bad Words, Press Y for Yes and N for No"); // story 2
            string ReadAnswer = string.Empty;

            ReadAnswer = Console.ReadLine();
            if (ReadAnswer.ToUpper() == "Y")
            {
                badWords = 0;
                if (content.Contains(bannedWord1))
                {
                    Console.WriteLine("Is this word '" + bannedWord1 + "' still bad as per new standards. Please Press Y for Bad and N or Ignore it as bad");
                    ReadAnswer = Console.ReadLine();
                    if (ReadAnswer.ToUpper() == "Y")
                    {
                        badWords = badWords + 1;
                    }
                }
                if (content.Contains(bannedWord2))
                {
                    Console.WriteLine("Is this word '" + bannedWord2 + "' still bad as per new standards. Please Press Y for Bad and N or Ignore it as bad");
                    ReadAnswer = Console.ReadLine();
                    if (ReadAnswer.ToUpper() == "Y")
                    {
                        badWords = badWords + 1;
                    }
                }
                if (content.Contains(bannedWord3))
                {
                    Console.WriteLine("Is this word '" + bannedWord3 + "' still bad as per new standards. Please Press Y for Bad and N or Ignore it as bad");
                    ReadAnswer = Console.ReadLine();
                    if (ReadAnswer.ToUpper() == "Y")
                    {
                        badWords = badWords + 1;
                    }
                }
                if (content.Contains(bannedWord4))
                {
                    Console.WriteLine("Is this word '" + bannedWord4 + "' still bad as per new standards. Please Press Y for Bad and N or Ignore it as bad");
                    ReadAnswer = Console.ReadLine();
                    if (ReadAnswer.ToUpper() == "Y")
                    {
                        badWords = badWords + 1;
                    }
                }

                Console.WriteLine("Scanned the text:");
                Console.WriteLine(content);
                Console.WriteLine("Total Number of negative words: " + badWords);
                Console.WriteLine("Do you want to Overwrite bad words with hashed words, Press Y for Yes and N for No"); // story 3
                ReadAnswer = string.Empty;

                ReadAnswer = Console.ReadLine();
                if (ReadAnswer.ToUpper() == "Y")
                {
                    if (content.Contains(bannedWord1))
                    {

                        string newupdatedword1 = string.Empty;
                        for (int i = 0; i < bannedWord1.Length; i++)
                        {
                            if (i == 0)
                            {
                                newupdatedword1 += bannedWord1[i];
                            }
                            else
                            {

                                if (i == bannedWord1.Length - 1)
                                {

                                    newupdatedword1 += bannedWord1[i];
                                }
                                else
                                {
                                    newupdatedword1 += '#';
                                }
                            }
                        }

                        content = content.Replace(bannedWord1, newupdatedword1);

                    }

                    if (content.Contains(bannedWord2))
                    {
                        string newupdatedword2 = string.Empty;
                        for (int i = 0; i < bannedWord2.Length; i++)
                        {
                            if (i == 0)
                            {
                                newupdatedword2 += bannedWord2[i];
                            }
                            else
                            {

                                if (i == bannedWord2.Length - 1)
                                {

                                    newupdatedword2 += bannedWord2[i];
                                }
                                else
                                {
                                    newupdatedword2 += '#';
                                }
                            }
                        }

                        content = content.Replace(bannedWord2, newupdatedword2);
                    }
                    if (content.Contains(bannedWord3))
                    {
                        string newupdatedword3 = string.Empty;
                        for (int i = 0; i < bannedWord3.Length; i++)
                        {
                            if (i == 0)
                            {
                                newupdatedword3 += bannedWord3[i];
                            }
                            else
                            {
                                if (i == bannedWord3.Length - 1)
                                {

                                    newupdatedword3 += bannedWord3[i];
                                }
                                else
                                {
                                    newupdatedword3 += '#';
                                }
                            }
                        }

                        content = content.Replace(bannedWord3, newupdatedword3);
                    }
                    if (content.Contains(bannedWord4))
                    {
                        string newupdatedword4 = string.Empty;
                        for (int i = 0; i < bannedWord4.Length; i++)
                        {
                            if (i == 0)
                            {
                                newupdatedword4 += bannedWord4[i];
                            }
                            else
                            {
                                if (i == bannedWord4.Length - 1)
                                {

                                    newupdatedword4 += bannedWord4[i];
                                }
                                else
                                {
                                    newupdatedword4 += '#';
                                }
                            }
                        }

                        content = content.Replace(bannedWord4, newupdatedword4);
                    }

                    Console.WriteLine("Scanned the text and here is updated text:");
                    Console.WriteLine(content);
                    Console.WriteLine("Do you want to go back to Original"); // story 3
                    ReadAnswer = string.Empty;

                    ReadAnswer = Console.ReadLine();
                    if (ReadAnswer.ToUpper() == "Y")
                    {
                        badWords = 0;
                        if (contentOriginal.Contains(bannedWord1))
                        {
                            badWords = badWords + 1;
                        }
                        if (contentOriginal.Contains(bannedWord2))
                        {
                            badWords = badWords + 1;
                        }
                        if (contentOriginal.Contains(bannedWord3))
                        {
                            badWords = badWords + 1;
                        }
                        if (contentOriginal.Contains(bannedWord4))
                        {
                            badWords = badWords + 1;
                        }

                        Console.WriteLine("Scanned the text:");
                        Console.WriteLine(contentOriginal);
                        Console.WriteLine("Total Number of negative words: " + badWords);

                        Console.WriteLine("Press ANY key to exit.");
                        Console.ReadKey();
                    }
                }




            }


        }

    }
}
